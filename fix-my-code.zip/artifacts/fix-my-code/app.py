import ast
import re
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

TYPO_FIXES = {
    r'\bpritn\b': 'print',
    r'\bprnit\b': 'print',
    r'\bpirnt\b': 'print',
    r'\bpirtn\b': 'print',
    r'\bpirnt\b': 'print',
    r'\bprtni\b': 'print',
    r'\bpinrt\b': 'print',
    r'\bprnt\b': 'print',
    r'\binpt\b': 'input',
    r'\binut\b': 'input',
    r'\binptu\b': 'input',
    r'\blne\b': 'len',
    r'\beln\b': 'len',
    r'\brnage\b': 'range',
    r'\brnge\b': 'range',
    r'\bragne\b': 'range',
    r'\bapepnd\b': 'append',
    r'\bappned\b': 'append',
    r'\bapend\b': 'append',
    r'\bTreu\b': 'True',
    r'\bTure\b': 'True',
    r'\bFlase\b': 'False',
    r'\bFalse\b': 'False',
    r'\bNoen\b': 'None',
    r'\bNoen\b': 'None',
    r'\bNone\b': 'None',
    r'\brturn\b': 'return',
    r'\bretunr\b': 'return',
    r'\bbrerak\b': 'break',
    r'\bcontinue\b': 'continue',
    r'\bimoprt\b': 'import',
    r'\bimport\b': 'import',
    r'\bform\s+(\w+)\s+import\b': r'from \1 import',
    r'\bfomr\b': 'from',
}

CONTROL_KEYWORDS = [
    'if', 'else', 'elif', 'for', 'while', 'def', 'class',
    'try', 'except', 'finally', 'with', 'async def', 'async for', 'async with'
]

MISSING_COLON_PATTERNS = [
    (re.compile(r'^(\s*)(if\b.+[^:])\s*$'), 'if statement'),
    (re.compile(r'^(\s*)(elif\b.+[^:])\s*$'), 'elif statement'),
    (re.compile(r'^(\s*)(else)\s*$'), 'else statement'),
    (re.compile(r'^(\s*)(for\b.+[^:])\s*$'), 'for loop'),
    (re.compile(r'^(\s*)(while\b.+[^:])\s*$'), 'while loop'),
    (re.compile(r'^(\s*)(def\b.+\)[^:])\s*$'), 'function definition'),
    (re.compile(r'^(\s*)(class\b.+[^:])\s*$'), 'class definition'),
    (re.compile(r'^(\s*)(try)\s*$'), 'try block'),
    (re.compile(r'^(\s*)(except.*[^:])\s*$'), 'except block'),
    (re.compile(r'^(\s*)(finally)\s*$'), 'finally block'),
    (re.compile(r'^(\s*)(with\b.+[^:])\s*$'), 'with statement'),
]

PRINT_PATTERN = re.compile(r'^(\s*)print\s+(.+)$')
PRINT_PAREN_CHECK = re.compile(r'^(\s*)print\s*\(')

BRACKET_PAIRS = {'(': ')', '[': ']', '{': '}'}
BRACKET_TIPS = {
    '(':  'Every opening ( needs a closing ) to match it — think of parentheses like a pair of hands cupping something: one opens, one closes.',
    '[':  'Every [ that opens a list needs a ] to close it — lists are like boxes, you open with [ and seal with ].',
    '{':  'Every { that opens a dictionary or set needs a } to close it.',
}
QUOTE_NAMES = {
    '"': 'double quote (")',
    "'": "single quote (')",
}


def normalize_indentation(lines):
    """Convert tabs to 4 spaces and normalize inconsistent mixed indentation."""
    fixed = []
    changes = []
    for i, line in enumerate(lines):
        if '\t' in line:
            new_line = line.replace('\t', '    ')
            if new_line != line:
                changes.append((i + 1, 'Replaced tab with 4 spaces'))
            fixed.append(new_line)
        else:
            fixed.append(line)
    return fixed, changes


def fix_print_statements(lines):
    """Convert Python 2 print statements to Python 3 function calls."""
    fixed = []
    changes = []
    for i, line in enumerate(lines):
        if PRINT_PAREN_CHECK.match(line):
            fixed.append(line)
            continue
        m = PRINT_PATTERN.match(line)
        if m:
            indent = m.group(1)
            content = m.group(2).strip()
            new_line = f'{indent}print({content})'
            if new_line.rstrip() != line.rstrip():
                changes.append((i + 1, f'Added parentheses to print statement (Python 3 syntax)'))
            fixed.append(new_line)
        else:
            fixed.append(line)
    return fixed, changes


def fix_typos(lines):
    """Fix common typos in Python keywords and built-in names."""
    fixed = []
    changes = []
    for i, line in enumerate(lines):
        original = line
        for pattern, replacement in TYPO_FIXES.items():
            new_line = re.sub(pattern, replacement, line)
            if new_line != line:
                changes.append((i + 1, f'Fixed typo: corrected to "{replacement}"'))
                line = new_line
        fixed.append(line)
    return fixed, changes


def fix_missing_colons(lines):
    """Add missing colons at the end of control flow statements."""
    fixed = []
    changes = []
    for i, line in enumerate(lines):
        stripped = line.rstrip()
        matched = False
        for pattern, desc in MISSING_COLON_PATTERNS:
            m = pattern.match(stripped)
            if m:
                new_line = stripped + ':'
                if stripped != new_line:
                    changes.append((i + 1, f'Added missing colon at end of {desc}'))
                    fixed.append(new_line + '\n' if line.endswith('\n') else new_line)
                    matched = True
                    break
        if not matched:
            fixed.append(line)
    return fixed, changes


def fix_brackets_and_quotes(lines):
    """
    Fix unclosed parentheses, brackets, braces, and quotes line by line.
    Uses a simple state machine that ignores characters inside strings and comments.
    """
    fixed = list(lines)
    changes = []

    in_triple = False
    triple_ch = None

    for i, line in enumerate(fixed):
        raw = line.rstrip('\n').rstrip('\r')

        # Skip blank lines and pure comment lines
        if not raw.strip() or raw.strip().startswith('#'):
            if in_triple:
                # Still inside a multi-line triple-quoted string
                if triple_ch and triple_ch * 3 in raw:
                    in_triple = False
                    triple_ch = None
            continue

        # If we're inside a triple-quoted string from a previous line,
        # just look for its closing sequence
        if in_triple:
            if triple_ch and triple_ch * 3 in raw:
                in_triple = False
                triple_ch = None
            continue

        bracket_stack = []   # list of opening bracket chars
        in_str = False
        str_ch = None
        result = list(raw)
        j = 0

        while j < len(result):
            c = result[j]

            if in_str:
                # Inside a regular string
                if c == '\\' and j + 1 < len(result):
                    j += 2
                    continue
                # End of triple string on this line
                if triple_ch and ''.join(result[j:j + 3]) == triple_ch * 3:
                    j += 3
                    in_str = False
                    in_triple = False
                    triple_ch = None
                    continue
                # End of regular string
                if not triple_ch and c == str_ch:
                    in_str = False
                    str_ch = None
                j += 1
                continue

            # Not inside a string
            if c == '#':
                # Rest of line is a comment — stop parsing
                break

            if c in ('"', "'"):
                # Triple quote?
                if ''.join(result[j:j + 3]) == c * 3:
                    in_str = True
                    triple_ch = c
                    in_triple = True
                    j += 3
                    # Check if closed on the same line
                    rest = ''.join(result[j:])
                    close = rest.find(c * 3)
                    if close != -1:
                        j = j + close + 3
                        in_str = False
                        triple_ch = None
                        in_triple = False
                    else:
                        j = len(result)
                    continue
                else:
                    in_str = True
                    str_ch = c
                    j += 1
                    continue

            if c in BRACKET_PAIRS:
                bracket_stack.append(c)
            elif c in BRACKET_PAIRS.values():
                # Check if it matches the most recent opener
                if bracket_stack:
                    expected = BRACKET_PAIRS[bracket_stack[-1]]
                    if c == expected:
                        bracket_stack.pop()
                    # Wrong closer: leave as-is (too risky to auto-swap)
                # Extra closer with nothing to match: leave as-is

            j += 1

        # ── After parsing this line ──

        # Case 1: unclosed bracket(s) on this line
        if bracket_stack and not in_str and not in_triple:
            missing = []
            while bracket_stack:
                opener = bracket_stack.pop()
                closer = BRACKET_PAIRS[opener]
                missing.append(closer)
                tip = BRACKET_TIPS[opener]
                changes.append((
                    i + 1,
                    f'Added missing closing "{closer}" — {tip}'
                ))
            suffix = ''.join(missing)
            new_raw = ''.join(result) + suffix
            fixed[i] = new_raw + ('\n' if line.endswith('\n') else '')

        # Case 2: unclosed regular string on this line
        elif in_str and not in_triple:
            q = str_ch
            qname = QUOTE_NAMES.get(q, f'"{q}"')
            changes.append((
                i + 1,
                f'Added missing closing {qname} — strings must have matching '
                f'quote marks at the start and end. You opened a string with '
                f'{q} but never closed it.'
            ))
            new_raw = ''.join(result) + q
            fixed[i] = new_raw + ('\n' if line.endswith('\n') else '')
            in_str = False
            str_ch = None

    return fixed, changes


def fix_equality_in_conditions(lines):
    """Fix assignment operator used instead of comparison in if/while conditions."""
    fixed = []
    changes = []
    pattern = re.compile(r'^(\s*(?:if|elif|while)\b.*?)(?<![=!<>])=(?![=])(.*)$')
    for i, line in enumerate(lines):
        m = pattern.match(line.rstrip())
        if m:
            new_line = m.group(1) + '==' + m.group(2)
            if line.rstrip() != new_line:
                changes.append((i + 1, 'Changed = to == (use == for comparison, = for assignment)'))
                fixed.append(new_line + '\n' if line.endswith('\n') else new_line)
            else:
                fixed.append(line)
        else:
            fixed.append(line)
    return fixed, changes


def get_syntax_error_info(code):
    """Try to parse the code and return syntax error details if any."""
    try:
        ast.parse(code)
        return None
    except SyntaxError as e:
        return {
            'line': e.lineno,
            'col': e.offset,
            'msg': e.msg,
            'text': e.text,
        }


def fix_code(original_code):
    """
    Apply a series of offline fixes to the given Python code.
    Returns fixed code, list of explanations, and whether the code is now valid.
    """
    all_changes = []

    lines = original_code.splitlines(keepends=True)
    if not lines:
        return original_code, [], False

    lines, c = normalize_indentation(lines)
    all_changes.extend(c)

    lines, c = fix_typos(lines)
    all_changes.extend(c)

    lines, c = fix_print_statements(lines)
    all_changes.extend(c)

    lines, c = fix_brackets_and_quotes(lines)
    all_changes.extend(c)

    lines, c = fix_missing_colons(lines)
    all_changes.extend(c)

    fixed_code = ''.join(lines)

    error_before = get_syntax_error_info(original_code)
    error_after = get_syntax_error_info(fixed_code)

    is_valid = error_after is None

    explanations = []
    for line_num, msg in all_changes:
        explanations.append({
            'line': line_num,
            'message': msg,
        })

    if not is_valid and error_after:
        explanations.append({
            'line': error_after['line'],
            'message': f'Remaining issue: {error_after["msg"]} — check this line manually',
            'warning': True,
        })

    if error_before and is_valid and not explanations:
        explanations.append({
            'line': None,
            'message': 'Code looks valid now — no fixes needed!',
        })

    return fixed_code, explanations, is_valid


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/fix', methods=['POST'])
def fix():
    data = request.get_json()
    if not data or 'code' not in data:
        return jsonify({'error': 'No code provided'}), 400

    original = data['code']
    if not original.strip():
        return jsonify({'error': 'Please paste some Python code first'}), 400

    fixed, explanations, is_valid = fix_code(original)

    syntax_error = get_syntax_error_info(original)
    error_info = None
    if syntax_error:
        error_info = {
            'line': syntax_error['line'],
            'message': syntax_error['msg'],
        }

    return jsonify({
        'original': original,
        'fixed': fixed,
        'explanations': explanations,
        'is_valid': is_valid,
        'had_error': syntax_error is not None,
        'error_info': error_info,
    })


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8000)
