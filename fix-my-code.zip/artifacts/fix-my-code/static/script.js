'use strict';

const codeInput = document.getElementById('code-input');
const codeOutput = document.getElementById('code-output');
const btnFix = document.getElementById('btn-fix');
const btnFixText = document.getElementById('btn-fix-text');
const fixIcon = document.getElementById('fix-icon');
const btnCopy = document.getElementById('btn-copy');
const btnClear = document.getElementById('btn-clear');
const btnExample = document.getElementById('btn-example');
const lineNumsInput = document.getElementById('line-numbers-input');
const lineNumsOutput = document.getElementById('line-numbers-output');
const charCount = document.getElementById('char-count');
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const explanationsSection = document.getElementById('explanations-section');
const explanationsList = document.getElementById('explanations-list');
const fixCount = document.getElementById('fix-count');
const toast = document.getElementById('toast');
const arrowHint = document.getElementById('arrow-hint');

const EXAMPLES = [
  `# Example 1: Multiple common mistakes

def calculate_sum(a, b)
    result = a + b
    rturn result

for i in rnage(5)
        pritn(i)

if x = 10
    print("x is ten")
else
    print("x is not ten")`,

  `# Example 2: Class and method errors

class Animal
    def __init__(self, name)
        self.name = name

    def speak(self)
        pritn(self.name, "makes a sound")

class Dog(Animal)
    def speak(self)
        pritn(self.name, "barks")

my_dog = Dog("Rex")
my_dog.speak()`,

  `# Example 3: Loops and conditions

numbers = [1, 2, 3, 4, 5]

for num in numbers
    if num % 2 = 0
        pritn(num, "is even")
    else
        pritn(num, "is odd")

while True
    user_input = inpt("Enter q to quit: ")
    if user_input = "q"
        break`,
];

let exampleIndex = 0;
let toastTimer = null;

function updateLineNumbers(textarea, container) {
  const lines = textarea.value.split('\n');
  container.textContent = lines.map((_, i) => i + 1).join('\n');
}

function syncScroll(textarea, lineNums) {
  lineNums.scrollTop = textarea.scrollTop;
}

function updateCharCount() {
  const lines = codeInput.value.split('\n').length;
  charCount.textContent = `${lines} line${lines !== 1 ? 's' : ''}`;
  arrowHint.textContent = codeInput.value.trim() ? '↑ click to fix' : '↑ paste code first';
}

function setStatus(type, text) {
  statusDot.className = 'status-dot' + (type ? ' ' + type : '');
  statusText.textContent = text;
}

function showToast(msg, duration = 2200) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), duration);
}

function setLoading(loading) {
  btnFix.disabled = loading;
  if (loading) {
    fixIcon.innerHTML = '<span class="spinner"></span>';
    btnFixText.textContent = 'Fixing…';
  } else {
    fixIcon.textContent = '⚡';
    btnFixText.textContent = 'Fix My Code';
  }
}

function renderExplanations(explanations, isValid) {
  explanationsList.innerHTML = '';

  if (!explanations || explanations.length === 0) {
    const li = document.createElement('li');
    li.className = 'explanation-item success';
    li.innerHTML = `<span class="exp-line" style="background:var(--green-dim);color:var(--green)">✓</span>
      <span class="exp-msg">No issues found — your code looks correct!</span>`;
    explanationsList.appendChild(li);
    fixCount.textContent = '0 changes';
  } else {
    const changes = explanations.filter(e => !e.warning);
    const warnings = explanations.filter(e => e.warning);
    fixCount.textContent = `${changes.length} fix${changes.length !== 1 ? 'es' : ''}${warnings.length ? ` + ${warnings.length} warning${warnings.length !== 1 ? 's' : ''}` : ''}`;

    explanations.forEach((exp, idx) => {
      const li = document.createElement('li');
      li.className = 'explanation-item' + (exp.warning ? ' warning' : '');
      li.style.animationDelay = `${idx * 0.05}s`;

      const lineLabel = exp.line
        ? `<span class="exp-line${exp.warning ? ' warning' : ''}">Line ${exp.line}</span>`
        : `<span class="exp-line" style="background:var(--green-dim);color:var(--green)">✓</span>`;

      li.innerHTML = `${lineLabel}<span class="exp-msg">${escapeHtml(exp.message)}</span>`;
      explanationsList.appendChild(li);
    });
  }

  explanationsSection.hidden = false;
  explanationsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function fixCode() {
  const code = codeInput.value;
  if (!code.trim()) {
    showToast('⚠️ Please paste some Python code first');
    codeInput.focus();
    return;
  }

  setLoading(true);
  setStatus('', 'Analyzing…');

  try {
    const resp = await fetch('/fix', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error || `Server error ${resp.status}`);
    }

    const data = await resp.json();

    codeOutput.value = data.fixed;
    codeOutput.classList.add('has-content');
    updateLineNumbers(codeOutput, lineNumsOutput);
    btnCopy.disabled = false;

    if (data.is_valid) {
      setStatus('ok', data.had_error ? 'Fixed! Code is now valid' : 'Code was already valid');
    } else {
      setStatus('partial', 'Partially fixed — some issues remain');
    }

    renderExplanations(data.explanations, data.is_valid);

  } catch (err) {
    setStatus('error', 'Error: ' + err.message);
    showToast('❌ ' + err.message, 3000);
  } finally {
    setLoading(false);
  }
}

function copyOutput() {
  const text = codeOutput.value;
  if (!text) return;
  navigator.clipboard.writeText(text).then(() => {
    showToast('✅ Copied to clipboard!');
  }).catch(() => {
    codeOutput.select();
    document.execCommand('copy');
    showToast('✅ Copied!');
  });
}

function clearAll() {
  codeInput.value = '';
  codeOutput.value = '';
  codeOutput.classList.remove('has-content');
  explanationsSection.hidden = true;
  explanationsList.innerHTML = '';
  btnCopy.disabled = true;
  setStatus('', 'Waiting for input');
  updateLineNumbers(codeInput, lineNumsInput);
  updateLineNumbers(codeOutput, lineNumsOutput);
  updateCharCount();
  codeInput.focus();
}

function loadExample() {
  codeInput.value = EXAMPLES[exampleIndex % EXAMPLES.length];
  exampleIndex++;
  updateLineNumbers(codeInput, lineNumsInput);
  updateCharCount();
  codeInput.focus();
  showToast('📋 Example loaded — click Fix My Code!');
}

// Wire up example cards
document.querySelectorAll('.example-card').forEach(card => {
  card.addEventListener('click', () => {
    const key = card.dataset.example;
    const map = {
      'missing-colon': `def greet(name)\n    print(name)\n\nif x > 5\n    print("big")\n\nfor i in range(3)\n    print(i)`,
      'print-statement': `print "Hello, World!"\nprint "My name is", "Alice"\nprint "Sum is", 1 + 2`,
      'indentation': `for i in range(5):\n\tprint(i)\n\tif i == 3:\n\t\tprint("three")\n\t\tif i > 2:\n\t\t\tprint("more than 2")`,
      'typo': `pritn("Hello")\nfor i in rnage(10):\n    pritn(i)\nx = lne([1, 2, 3])\npritn("Length:", x)`,
      'brackets': `print("Hello, World!"\nnames = ["Alice", "Bob", "Charlie"\nscores = {"Alice": 95, "Bob": 87\nprint(names[0]\nprint(scores["Alice"]`,
      'quotes': `name = "Alice\ngreeting = 'Hello, world!\nmessage = "Welcome to Python\nprint(name)\nprint(greeting)\nprint(message)`,
    };
    if (map[key]) {
      codeInput.value = map[key];
      updateLineNumbers(codeInput, lineNumsInput);
      updateCharCount();
      codeInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
      showToast('📋 Example loaded — click Fix My Code!');
    }
  });
});

// Events
btnFix.addEventListener('click', fixCode);
btnCopy.addEventListener('click', copyOutput);
btnClear.addEventListener('click', clearAll);
btnExample.addEventListener('click', loadExample);

codeInput.addEventListener('input', () => {
  updateLineNumbers(codeInput, lineNumsInput);
  updateCharCount();
});

codeInput.addEventListener('keydown', e => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const start = codeInput.selectionStart;
    const end = codeInput.selectionEnd;
    codeInput.value = codeInput.value.substring(0, start) + '    ' + codeInput.value.substring(end);
    codeInput.selectionStart = codeInput.selectionEnd = start + 4;
    updateLineNumbers(codeInput, lineNumsInput);
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    fixCode();
  }
});

codeInput.addEventListener('scroll', () => syncScroll(codeInput, lineNumsInput));
codeOutput.addEventListener('scroll', () => syncScroll(codeOutput, lineNumsOutput));

// Init
updateLineNumbers(codeInput, lineNumsInput);
updateLineNumbers(codeOutput, lineNumsOutput);
updateCharCount();
