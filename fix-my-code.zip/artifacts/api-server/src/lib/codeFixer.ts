export interface FixExplanation {
  line: number | null;
  message: string;
  warning?: boolean;
}

export interface FixResult {
  original: string;
  fixed: string;
  explanations: FixExplanation[];
  isValid: boolean;
  hadError: boolean;
  errorInfo: { line: number | null; message: string } | null;
}

const TYPO_MAP: Record<string, string> = {
  pritn: "print",
  prnt: "print",
  prnit: "print",
  pirnt: "print",
  prit: "print",
  prtin: "print",
  rnage: "range",
  raange: "range",
  ragne: "range",
  lenngh: "len",
  lenght: "len",
  leng: "len",
  apeend: "append",
  appedn: "append",
  apend: "append",
  improt: "import",
  imoprt: "import",
  ipmort: "import",
  whlie: "while",
  whiel: "while",
  retrun: "return",
  reutrn: "return",
  Flase: "False",
  flase: "False",
  Ture: "True",
  ture: "True",
  Noen: "None",
  noen: "None",
  breeak: "break",
  contniue: "continue",
  passs: "pass",
};

function normalizeIndentation(lines: string[]): {
  lines: string[];
  explanations: FixExplanation[];
} {
  const explanations: FixExplanation[] = [];
  const result: string[] = [];
  let fixed = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes("\t")) {
      const fixedLine = line.replace(/\t/g, "    ");
      result.push(fixedLine);
      if (!fixed) {
        explanations.push({
          line: i + 1,
          message:
            "Replaced tabs with 4 spaces. Python prefers spaces over tabs — mixing them causes indentation errors.",
        });
        fixed = true;
      }
    } else {
      result.push(line);
    }
  }

  return { lines: result, explanations };
}

function fixTypos(lines: string[]): {
  lines: string[];
  explanations: FixExplanation[];
} {
  const explanations: FixExplanation[] = [];
  const result: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];
    let changed = false;

    for (const [typo, correct] of Object.entries(TYPO_MAP)) {
      const regex = new RegExp(`\\b${typo}\\b`, "g");
      if (regex.test(line)) {
        line = line.replace(regex, correct);
        if (!changed) {
          explanations.push({
            line: i + 1,
            message: `Fixed typo: "${typo}" → "${correct}". This is a common misspelling of the Python keyword.`,
          });
          changed = true;
        }
      }
    }

    result.push(line);
  }

  return { lines: result, explanations };
}

function fixPrintStatements(lines: string[]): {
  lines: string[];
  explanations: FixExplanation[];
} {
  const explanations: FixExplanation[] = [];
  const result: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trimStart();
    const indent = line.slice(0, line.length - trimmed.length);

    const printMatch = trimmed.match(/^print\s+(.+)$/);
    if (printMatch) {
      const arg = printMatch[1].trim();
      if (!arg.startsWith("(")) {
        result.push(`${indent}print(${arg})`);
        explanations.push({
          line: i + 1,
          message: `Converted Python 2 print statement to Python 3: "print ${arg}" → "print(${arg})". In Python 3, print is a function and needs parentheses.`,
        });
        continue;
      }
    }

    result.push(line);
  }

  return { lines: result, explanations };
}

function fixBracketsAndQuotes(lines: string[]): {
  lines: string[];
  explanations: FixExplanation[];
} {
  const explanations: FixExplanation[] = [];
  const result: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let inSingleQuote = false;
    let inDoubleQuote = false;
    const stack: string[] = [];
    let j = 0;

    while (j < line.length) {
      const ch = line[j];

      if (ch === "\\") {
        j += 2;
        continue;
      }

      if (ch === "'" && !inDoubleQuote) {
        inSingleQuote = !inSingleQuote;
      } else if (ch === '"' && !inSingleQuote) {
        inDoubleQuote = !inDoubleQuote;
      } else if (!inSingleQuote && !inDoubleQuote) {
        if (ch === "(" || ch === "[" || ch === "{") {
          stack.push(ch);
        } else if (ch === ")" || ch === "]" || ch === "}") {
          if (stack.length > 0) {
            stack.pop();
          }
        }
      }

      j++;
    }

    let fixedLine = line;
    if (!inSingleQuote && !inDoubleQuote && stack.length > 0) {
      const closing = stack
        .reverse()
        .map((b) => (b === "(" ? ")" : b === "[" ? "]" : "}"))
        .join("");
      fixedLine = line + closing;
      explanations.push({
        line: i + 1,
        message: `Added missing closing bracket(s) "${closing}" at end of line. Every opening bracket must have a matching closing bracket.`,
      });
    } else if (inSingleQuote) {
      fixedLine = line + "'";
      explanations.push({
        line: i + 1,
        message: `Added missing closing single quote. Every opening quote must be closed.`,
      });
    } else if (inDoubleQuote) {
      fixedLine = line + '"';
      explanations.push({
        line: i + 1,
        message: `Added missing closing double quote. Every opening quote must be closed.`,
      });
    }

    result.push(fixedLine);
  }

  return { lines: result, explanations };
}

const COLON_PATTERNS = [
  /^(if\s+.+[^:])$/,
  /^(elif\s+.+[^:])$/,
  /^(else\s*)$/,
  /^(for\s+.+[^:])$/,
  /^(while\s+.+[^:])$/,
  /^(def\s+\w+\s*\(.*\)\s*)$/,
  /^(class\s+\w+.*[^:])$/,
  /^(try\s*)$/,
  /^(except(?:\s+.*)?[^:])$/,
  /^(finally\s*)$/,
  /^(with\s+.+[^:])$/,
];

function fixMissingColons(lines: string[]): {
  lines: string[];
  explanations: FixExplanation[];
} {
  const explanations: FixExplanation[] = [];
  const result: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trimStart();
    const indent = line.slice(0, line.length - trimmed.length);

    let matched = false;
    for (const pattern of COLON_PATTERNS) {
      const m = trimmed.match(pattern);
      if (m) {
        const fixedLine = `${indent}${trimmed}:`;
        result.push(fixedLine);
        explanations.push({
          line: i + 1,
          message: `Added missing colon at end of line. Python requires a colon (:) after if/else/for/while/def/class/try/except/with statements.`,
        });
        matched = true;
        break;
      }
    }

    if (!matched) {
      result.push(line);
    }
  }

  return { lines: result, explanations };
}

function detectSyntaxError(code: string): {
  hasError: boolean;
  errorInfo: { line: number | null; message: string } | null;
} {
  const lines = code.split("\n");

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trimStart();

    if (!trimmed || trimmed.startsWith("#")) continue;

    const openParens = (line.match(/\(/g) || []).length;
    const closeParens = (line.match(/\)/g) || []).length;
    const openBrackets = (line.match(/\[/g) || []).length;
    const closeBrackets = (line.match(/\]/g) || []).length;

    if (openParens !== closeParens || openBrackets !== closeBrackets) {
      return {
        hasError: true,
        errorInfo: {
          line: i + 1,
          message: `Unmatched brackets or parentheses on line ${i + 1}.`,
        },
      };
    }
  }

  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trimStart();
    if (!trimmed || trimmed.startsWith("#")) continue;

    const needsColon = [
      /^if\s+/,
      /^elif\s+/,
      /^else\s*$/,
      /^for\s+/,
      /^while\s+/,
      /^def\s+/,
      /^class\s+/,
      /^try\s*$/,
      /^except/,
      /^finally\s*$/,
      /^with\s+/,
    ];

    for (const pattern of needsColon) {
      if (pattern.test(trimmed) && !trimmed.trimEnd().endsWith(":")) {
        return {
          hasError: true,
          errorInfo: {
            line: i + 1,
            message: `Missing colon at end of line ${i + 1}: "${trimmed}"`,
          },
        };
      }
    }
  }

  return { hasError: false, errorInfo: null };
}

export function fixCode(code: string): FixResult {
  const original = code;
  const allExplanations: FixExplanation[] = [];

  const originalSyntax = detectSyntaxError(code);
  const hadError = originalSyntax.hasError;

  let lines = code.split("\n");

  const indentResult = normalizeIndentation(lines);
  lines = indentResult.lines;
  allExplanations.push(...indentResult.explanations);

  const typoResult = fixTypos(lines);
  lines = typoResult.lines;
  allExplanations.push(...typoResult.explanations);

  const printResult = fixPrintStatements(lines);
  lines = printResult.lines;
  allExplanations.push(...printResult.explanations);

  const colonResult = fixMissingColons(lines);
  lines = colonResult.lines;
  allExplanations.push(...colonResult.explanations);

  const bracketResult = fixBracketsAndQuotes(lines);
  lines = bracketResult.lines;
  allExplanations.push(...bracketResult.explanations);

  const fixed = lines.join("\n");

  const afterSyntax = detectSyntaxError(fixed);
  const isValid = !afterSyntax.hasError;

  if (!isValid && afterSyntax.errorInfo) {
    allExplanations.push({
      line: afterSyntax.errorInfo.line,
      message: `Heads up: there may still be a problem on this line: ${afterSyntax.errorInfo.message}`,
      warning: true,
    });
  }

  if (allExplanations.length === 0) {
    allExplanations.push({
      line: null,
      message:
        "No issues found! Your code looks good. If you still see errors, double-check the logic of your program.",
    });
  }

  return {
    original,
    fixed,
    explanations: allExplanations,
    isValid,
    hadError,
    errorInfo: originalSyntax.errorInfo,
  };
}
