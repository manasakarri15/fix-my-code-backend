import { Router, type IRouter } from "express";
import healthRouter from "./health";
import fixRouter from "./fix";

const router: IRouter = Router();

router.use(healthRouter);
router.use(fixRouter);

export default router;
