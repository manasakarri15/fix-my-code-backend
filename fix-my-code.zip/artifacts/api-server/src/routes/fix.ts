import { Router, type IRouter } from "express";
import { FixCodeBody } from "@workspace/api-zod";
import { fixCode } from "../lib/codeFixer";

const router: IRouter = Router();

router.post("/fix", async (req, res): Promise<void> => {
  const parsed = FixCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { code } = parsed.data;

  if (typeof code !== "string") {
    res.status(400).json({ error: "code must be a string" });
    return;
  }

  const result = fixCode(code);
  res.json(result);
});

export default router;
