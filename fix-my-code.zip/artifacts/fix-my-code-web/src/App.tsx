import { useState, KeyboardEvent } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2, AlertTriangle, Wand2, Terminal, ChevronRight, Loader2, Info, Code2 } from "lucide-react";
import { useFixCode } from "@workspace/api-client-react";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

const EXAMPLES = [
  {
    title: "Missing colon",
    code: 'score = 90\nif score >= 50\n    print("Pass")'
  },
  {
    title: "Mixed indentation",
    code: 'def greet():\n\tprint("Hello")\n    print("World")'
  },
  {
    title: "Python 2 print",
    code: 'print "Hello World"'
  },
  {
    title: "Typo in function",
    code: 'pritn("Hello")'
  },
  {
    title: "Unmatched paren",
    code: 'print("Hello"'
  },
  {
    title: "Missing def colon",
    code: 'def say_hello()\n    print("Hi")'
  }
];

function Home() {
  const [code, setCode] = useState("");
  const fixCodeMutation = useFixCode();

  const handleFix = () => {
    if (!code.trim()) return;
    fixCodeMutation.mutate({ data: { code } });
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      handleFix();
    }
  };

  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col font-sans">
      <header className="border-b bg-card px-6 py-4 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
            <Wand2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground leading-tight tracking-tight">Fix My Code</h1>
            <p className="text-sm text-muted-foreground font-medium">Your patient Python mentor</p>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Left Column: Input */}
        <div className="flex flex-col gap-4">
          <Card className="p-4 flex flex-col gap-4 shadow-md border-border/50 bg-card">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Terminal className="w-4 h-4 text-primary" />
                <span>Paste your broken Python code</span>
              </div>
              <Badge variant="secondary" className="text-xs font-mono text-muted-foreground bg-muted/50 border-none">
                Ctrl + Enter to fix
              </Badge>
            </div>
            
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="def hello_world()\n    print('Hello')"
              className="min-h-[300px] font-mono text-sm resize-y bg-muted/30 border-muted focus-visible:ring-primary/50 focus-visible:border-primary/50 p-4"
              data-testid="input-code"
            />

            <Button 
              onClick={handleFix} 
              disabled={!code.trim() || fixCodeMutation.isPending}
              className="w-full sm:w-auto self-end font-semibold shadow-sm"
              size="lg"
              data-testid="button-fix-code"
            >
              {fixCodeMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4 mr-2" />
                  Fix My Code
                </>
              )}
            </Button>
          </Card>

          <div>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 px-1 uppercase tracking-wider">Try an example</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {EXAMPLES.map((example, i) => (
                <button
                  key={i}
                  onClick={() => setCode(example.code)}
                  className="text-left px-3 py-2 rounded-lg border border-border/50 bg-card hover:bg-muted/50 hover:border-primary/30 transition-colors text-sm font-medium text-foreground shadow-sm"
                  data-testid={`button-example-${i}`}
                >
                  {example.title}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Output */}
        <div className="flex flex-col h-full min-h-[400px]">
          {fixCodeMutation.isPending ? (
            <Card className="flex-1 flex flex-col items-center justify-center p-8 text-center text-muted-foreground border-dashed bg-muted/10 animate-pulse">
              <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4">
                <Loader2 className="w-8 h-8 animate-spin" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-1">Reading your code...</h3>
              <p className="text-sm max-w-[250px]">Looking for syntax errors, missing colons, and typos.</p>
            </Card>
          ) : fixCodeMutation.data ? (
            <div className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both">
              
              {/* Status Header */}
              <Card className={`p-4 border-l-4 shadow-sm ${fixCodeMutation.data.isValid ? 'border-l-green-500 bg-green-50/30' : 'border-l-destructive bg-destructive/5'}`}>
                <div className="flex items-start gap-3">
                  {fixCodeMutation.data.isValid ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-destructive mt-0.5" />
                  )}
                  <div>
                    <h3 className={`font-semibold ${fixCodeMutation.data.isValid ? 'text-green-900 dark:text-green-400' : 'text-destructive'}`}>
                      {fixCodeMutation.data.isValid 
                        ? (fixCodeMutation.data.hadError ? "Fixed successfully!" : "Your code looks good!") 
                        : "There are still some issues"}
                    </h3>
                    {!fixCodeMutation.data.isValid && fixCodeMutation.data.errorInfo && (
                      <p className="text-sm text-destructive/80 mt-1 font-medium">
                        {fixCodeMutation.data.errorInfo.line && `Line ${fixCodeMutation.data.errorInfo.line}: `}
                        {fixCodeMutation.data.errorInfo.message}
                      </p>
                    )}
                  </div>
                </div>
              </Card>

              {/* Explanations */}
              {fixCodeMutation.data.explanations.length > 0 && (
                <div className="flex flex-col gap-3">
                  <h3 className="text-sm font-semibold text-muted-foreground px-1 uppercase tracking-wider">What changed</h3>
                  {fixCodeMutation.data.explanations.map((exp, i) => (
                    <Card key={i} className="p-4 shadow-sm border-border/50">
                      <div className="flex gap-3 items-start">
                        <div className="mt-0.5">
                          {exp.warning ? (
                            <AlertTriangle className="w-5 h-5 text-amber-500" />
                          ) : (
                            <Info className="w-5 h-5 text-primary" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm text-foreground leading-relaxed font-medium">
                            {exp.message}
                          </p>
                          {exp.line !== null && exp.line !== undefined && (
                            <div className="mt-2 inline-flex items-center text-xs font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded-md">
                              Line {exp.line}
                            </div>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Fixed Code Viewer */}
              {fixCodeMutation.data.isValid && fixCodeMutation.data.hadError && (
                <Card className="p-0 overflow-hidden shadow-md border-border/50 flex flex-col mt-2">
                  <div className="bg-muted/50 px-4 py-2 border-b flex items-center justify-between">
                    <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Fixed Code</span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-7 text-xs font-medium"
                      onClick={() => {
                        navigator.clipboard.writeText(fixCodeMutation.data.fixed);
                      }}
                    >
                      Copy Code
                    </Button>
                  </div>
                  <div className="p-4 bg-zinc-950 text-zinc-50 overflow-auto text-sm font-mono leading-relaxed whitespace-pre-wrap">
                    {fixCodeMutation.data.fixed}
                  </div>
                </Card>
              )}
              
            </div>
          ) : (
            <Card className="flex-1 flex flex-col items-center justify-center p-8 text-center text-muted-foreground border-dashed bg-muted/10">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Code2 className="w-8 h-8 text-muted-foreground/50" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-1">Ready to help</h3>
              <p className="text-sm max-w-[250px]">Paste your code and click Fix Code to see the magic happen.</p>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
