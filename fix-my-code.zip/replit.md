# Fix My Code

A Python Flask web app that helps beginners fix common Python syntax and indentation errors — fully offline, no AI or external APIs.

## Run & Operate

- **Fix My Code (Flask)**: Workflow `Fix My Code` — `python3 artifacts/fix-my-code/app.py 8000` (port 8000)
- `pnpm --filter @workspace/api-server run dev` — run the Node.js API server (port 8080, path /api)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages

## Stack

- **Fix My Code**: Python 3.11, Flask 3, vanilla HTML/CSS/JS
- **API Server** (unused by Fix My Code): Node.js 24, Express 5, TypeScript 5.9
- DB: PostgreSQL + Drizzle ORM (api-server only)

## Where things live

- `artifacts/fix-my-code/app.py` — Flask app + all Python fixing logic
- `artifacts/fix-my-code/templates/index.html` — Dark-themed HTML page
- `artifacts/fix-my-code/static/style.css` — Styles
- `artifacts/fix-my-code/static/script.js` — Client-side JS

## Architecture decisions

- All fixing is done server-side with Python's `ast` module — no external APIs.
- Fixes are applied in order: tabs→spaces → typos → print statements → missing colons.
- Each fix returns a line number and human-readable explanation for the user.
- Flask served on port 8000 via a Replit workflow.

## Product

- Paste broken Python code → click "Fix My Code" → see corrected code + plain-English explanations.
- Fixes: missing colons, tab indentation, Python 2 print statements, common keyword typos (pritn, rnage, etc.).
- Four clickable example cards show the most common beginner mistakes.
- Keyboard shortcut: Ctrl/Cmd+Enter to fix.

## User preferences

- No AI or external APIs — pure Python logic only.
- Beginner-friendly explanations for every fix.
- Modern dark theme.

## Gotchas

- Flask must be installed: `python3 -m pip install flask`
- The `Fix My Code` workflow must be running for the app to load.
- Port 8000 is used by Flask; port 8080 by the Node.js api-server.
